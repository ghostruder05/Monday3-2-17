package com.cg.ARS.testcases;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ARS.daos.BookingDao;
import com.cg.ARS.daos.BookingDaoImpl;
import com.cg.ARS.dto.FlightInfo;
import com.cg.ARS.exceptions.BookingExceptions;

public class UpdateTest {
	BookingDao dao=null;
	FlightInfo flight=null;
	//BookingDao dao;
	private static final Logger mylogger=
			Logger.getLogger(UpdateTest.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		dao= new BookingDaoImpl();

		//dao= new BookingDaoImpl();
		flight  = new FlightInfo();
		
		
		flight.setFlightno("A101");
		
		flight.setAirlinename("AirIndia");
		flight.setDept_city("Goa");
		flight.setArr_city("Pune");
		
		flight.setDep_time("07:00PM");
		flight.setArr_time("11:00PM");
		flight.setFirstseats(10);
		flight.setFirstseatfare(5000);
		flight.setBussseats(20);
		flight.setBussseatfare(3000);
		
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
		
		flight=null;
	
	}

	@Test
	public void test() {
		try {
			assertNotNull(dao.updateFlightInfo(flight));
		} catch (BookingExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
