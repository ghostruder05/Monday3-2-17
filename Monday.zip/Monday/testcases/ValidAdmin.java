package com.cg.ARS.testcases;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ARS.daos.BookingDao;
import com.cg.ARS.daos.BookingDaoImpl;
import com.cg.ARS.exceptions.BookingExceptions;

public class ValidAdmin {

	BookingDao dao;
	private static final Logger mylogger=
			Logger.getLogger(ValidAdmin.class);
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		dao= new BookingDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void test() {
		try {
			assertTrue(dao.validateAdmin("admin"));
			System.out.println(dao.validateAdmin("user1"));
		} catch (BookingExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
