package com.cg.ARS.testcases;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ARS.daos.BookingDao;
import com.cg.ARS.daos.BookingDaoImpl;
import com.cg.ARS.dto.BookingInformation;
import com.cg.ARS.dto.FlightInfo;
import com.cg.ARS.exceptions.BookingExceptions;

public class AddBooking {


	BookingDao dao=null;
	BookingInformation book =null;
	
	private static final Logger mylogger=
			Logger.getLogger(AddBooking.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		dao= new BookingDaoImpl();
		book= new BookingInformation();
		
	//	book.setBooking_id("");
		book.setClass_type("First");
		book.setCreditcard_info("233564687646756");
		book.setCust_email("gfg@gmail.com");
		book.setDest_city("Pune");
		book.setFlightno("A101");
		book.setNo_of_passenger(4);
		book.setSeat_number(3);
		book.setSrc_city("Mumbai");
		book.setTotal_fare(5000);
		
		
		
		
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
		book=null;
	}

	@Test
	public void test() {
		try {
			assertTrue(dao.addBookingDetails(book));
		} catch (BookingExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void asserTrue(boolean addBookingDetails) {
		// TODO Auto-generated method stub
		
	}

}
