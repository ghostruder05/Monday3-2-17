package com.cg.ARS.testcases;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ARS.daos.BookingDao;
import com.cg.ARS.daos.BookingDaoImpl;
import com.cg.ARS.exceptions.BookingExceptions;

public class GetFlightNo {

	BookingDao dao;
	private static final Logger mylogger=
			Logger.getLogger(GetFlightNo.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		dao= new BookingDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testGetFlightNo() {
		try {
			String str=dao.getFlightNo("Mumbai", "Goa");
			assertequals("A109",str);
			System.out.println(dao.getFlightNo("Mumbai", "Goa"));
		} catch (BookingExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void assertequals(String string, String str) {
		// TODO Auto-generated method stub
		
	}

}
